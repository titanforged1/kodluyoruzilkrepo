function showTime() {
    const clockElement = document.querySelector("#myClock")
    
    setInterval(() => {
        const date = new Date()
        const day = date.toUTCString().split(",")[0]
        const seconds = date.getSeconds()
        const minutes = date.getMinutes()
        const hours = date.getHours()
        const time = `${hours}:${minutes}:${seconds}\t${day}`

        clockElement.innerHTML = time
    }, 1000)
}


window.addEventListener("load",  (event) => {
    showTime()
})
